## Mail App

Mail App Merupakan aplikasi CRUD sederhana berbasis web  yang dibuat menggunakan HTML, CSS, PHP dan JavaScript, adapun beberapa fitur dari Mail App antara lain :

* Mampu mengimplementasikan CRUD
* Search
* Filter
* PWA (Progressive Web Apps)


Komponen atau Framework tambahan  untuk membangun mail app antara lain :

* Bootstrap
* GSAP
* Datatable

Anda bisa mengakses aplikasi mail app dengan mengeklik tautan dibawah ini :

[Mail App](https://is-mail.herokuapp.com)


> [Author by Faizalilham](https://www.instagram.com/faizalfalakh/) 
